#!/bin/bash
#
# No local compilation is required for this Python-only lab.

