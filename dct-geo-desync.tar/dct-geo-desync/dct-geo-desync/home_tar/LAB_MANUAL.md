# DCT Geo Desynchronization

Chu de: tan cong desynchronization vao giau tin anh DCT bang translation,
crop va rotation nhe.

Trong lab nay, thong diep duoc nhung vao mien tan so DCT theo cac block 8x8.
Khi anh bi dich, crop hoac xoay nhe, luoi block 8x8 cua bo trich xuat khong
con trung voi luoi nhung ban dau. Ket qua la cac he so DCT duoc doc tu block
sai, lam BER tang manh du anh nhin bang mat van gan nhu khong thay doi.

## Quy tac

- Chi sua `lab_config.yaml` va `report.md`.
- Khong sua `dct_desync_core.py`, `setup_lab.py` hoac `run_task.py` khi nop bai.
- Khong co solve-all script. Hay chay tung task va quan sat anh/report.
- Cac anh PGM co the mo bang viewer anh hoac copy ra host neu can.
- Cac file ban dau da duoc tao san khi lab khoi dong. Khong can chay
  `python3 setup_lab.py` truoc khi lam bai.

## Workflow

Khi lab khoi dong, cac file ban dau da co san: `cover.pgm`, `stego.pgm`,
`lab_config.yaml`, `metrics.csv`, `report.md`.

Neu can reset ve trang thai ban dau, co the chay:

```bash
python3 setup_lab.py
```

Luu y: lenh reset nay se ghi de `lab_config.yaml`, `metrics.csv` va
`report.md`.

Task 1:

```bash
python3 run_task.py --task grid
```

Task 2:

```bash
python3 run_task.py --task baseline
```

Task 3 den Task 8: mo `lab_config.yaml`, sua tham so cua tung attack, roi
chay:

```bash
python3 run_task.py --task translate_small
python3 run_task.py --task translate_large
python3 run_task.py --task crop_margin
python3 run_task.py --task crop_window
python3 run_task.py --task rotate_cw
python3 run_task.py --task rotate_ccw
```

Moi task tren phai tao mot anh `attacked_*.pgm` khac nhau. Tong cong nguoi hoc
phai tao it nhat 6 anh attacked.

Task 9: viet phan tich vao `report.md`, sau do chay:

```bash
python3 run_task.py --task report
```

Report can noi ro:

- Vi sao lech block 8x8 lam trich xuat DCT sai.
- Translation/crop/rotation gay desynchronization khac nhau nhu the nao.
- BER, PSNR, SSIM trong `metrics.csv` noi len dieu gi.

## Checkwork

Thoat container ve host Labtainer:

```bash
exit
```

Chay:

```bash
checkwork dct-geo-desync
```
