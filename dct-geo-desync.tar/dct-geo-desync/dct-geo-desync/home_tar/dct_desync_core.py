import math
import random
from pathlib import Path


WIDTH = 256
HEIGHT = 256
BLOCK = 8
MESSAGE = "LAB02 DCT DESYNC"
COEFF_A = (3, 4)
COEFF_B = (4, 3)
FILL = 128.0

COS = [[math.cos((2 * x + 1) * u * math.pi / 16.0) for x in range(BLOCK)] for u in range(BLOCK)]
ALPHA = [1.0 / math.sqrt(2.0)] + [1.0] * 7


def clamp(v):
    return int(max(0, min(255, round(v))))


def text_to_bits(text):
    bits = []
    for ch in text.encode("utf-8"):
        bits.extend([(ch >> i) & 1 for i in range(7, -1, -1)])
    return bits


def bits_to_text(bits):
    data = []
    for i in range(0, len(bits), 8):
        byte = 0
        for bit in bits[i : i + 8]:
            byte = (byte << 1) | bit
        data.append(byte)
    return bytes(data).decode("utf-8", errors="replace")


def make_cover():
    img = []
    rnd = random.Random(20260202)
    for y in range(HEIGHT):
        row = []
        for x in range(WIDTH):
            base = 118 + 38 * math.sin(x / 15.0) + 31 * math.cos(y / 19.0)
            texture = 15 * math.sin((2 * x + y) / 23.0) + 10 * math.cos((x - y) / 17.0)
            row.append(clamp(base + texture + rnd.randint(-4, 4)))
        img.append(row)
    return img


def save_pgm(path, pixels):
    h = len(pixels)
    w = len(pixels[0])
    with open(path, "wb") as f:
        f.write(f"P5\n{w} {h}\n255\n".encode("ascii"))
        f.write(bytes(clamp(v) for row in pixels for v in row))


def load_pgm(path):
    data = Path(path).read_bytes()
    if not data.startswith(b"P5"):
        raise ValueError("Only PGM P5 images are supported")
    parts = []
    i = 0
    while len(parts) < 4:
        while data[i] in b" \t\r\n":
            i += 1
        if data[i] == ord("#"):
            while data[i] != ord("\n"):
                i += 1
            continue
        j = i
        while data[j] not in b" \t\r\n":
            j += 1
        parts.append(data[i:j])
        i = j
    _, w, h, maxv = parts
    if int(maxv) != 255:
        raise ValueError("Expected max value 255")
    while data[i] in b" \t\r\n":
        i += 1
    w = int(w)
    h = int(h)
    raw = data[i : i + w * h]
    return [list(raw[y * w : (y + 1) * w]) for y in range(h)]


def dct2(block):
    out = [[0.0] * BLOCK for _ in range(BLOCK)]
    for u in range(BLOCK):
        for v in range(BLOCK):
            s = 0.0
            for y in range(BLOCK):
                for x in range(BLOCK):
                    s += (block[y][x] - 128.0) * COS[u][x] * COS[v][y]
            out[u][v] = 0.25 * ALPHA[u] * ALPHA[v] * s
    return out


def idct2(coeff):
    out = [[0.0] * BLOCK for _ in range(BLOCK)]
    for y in range(BLOCK):
        for x in range(BLOCK):
            s = 0.0
            for u in range(BLOCK):
                for v in range(BLOCK):
                    s += ALPHA[u] * ALPHA[v] * coeff[u][v] * COS[u][x] * COS[v][y]
            out[y][x] = 128.0 + 0.25 * s
    return out


def candidate_blocks():
    coords = []
    for by in range(2, HEIGHT // BLOCK - 2):
        for bx in range(2, WIDTH // BLOCK - 2):
            coords.append((bx * BLOCK, by * BLOCK))
    return coords


def selected_blocks(key, count):
    coords = candidate_blocks()
    rnd = random.Random(key)
    rnd.shuffle(coords)
    if count > len(coords):
        raise ValueError("Payload too large for available DCT blocks")
    return coords[:count]


def get_block(pixels, x0, y0):
    return [[float(pixels[y0 + y][x0 + x]) for x in range(BLOCK)] for y in range(BLOCK)]


def put_block(pixels, x0, y0, block):
    for y in range(BLOCK):
        for x in range(BLOCK):
            pixels[y0 + y][x0 + x] = clamp(block[y][x])


def force_relation(coeff, bit, delta):
    au, av = COEFF_A
    bu, bv = COEFF_B
    a = coeff[au][av]
    b = coeff[bu][bv]
    diff = a - b if bit else b - a
    if diff >= delta:
        return
    change = (delta - diff) / 2.0
    if bit:
        coeff[au][av] = a + change
        coeff[bu][bv] = b - change
    else:
        coeff[au][av] = a - change
        coeff[bu][bv] = b + change


def embed_message(cover, message, key, delta, repeat_count):
    bits = text_to_bits(message)
    out = [row[:] for row in cover]
    coords = selected_blocks(key, len(bits) * repeat_count)
    for i, (x0, y0) in enumerate(coords):
        bit = bits[i // repeat_count]
        coeff = dct2(get_block(out, x0, y0))
        force_relation(coeff, bit, float(delta))
        put_block(out, x0, y0, idct2(coeff))
    return out


def extract_message(pixels, bit_count, key, repeat_count):
    coords = selected_blocks(key, bit_count * repeat_count)
    bits = []
    margins = []
    for i in range(bit_count):
        votes = 0
        for x0, y0 in coords[i * repeat_count : (i + 1) * repeat_count]:
            coeff = dct2(get_block(pixels, x0, y0))
            au, av = COEFF_A
            bu, bv = COEFF_B
            votes += 1 if coeff[au][av] > coeff[bu][bv] else -1
        bits.append(1 if votes > 0 else 0)
        margins.append(votes)
    return bits_to_text(bits), bits, margins


def bit_error_rate(expected, actual):
    return 100.0 * sum(1 for a, b in zip(expected, actual) if a != b) / len(expected)


def sample(pixels, x, y):
    h = len(pixels)
    w = len(pixels[0])
    if x < 0 or y < 0 or x >= w - 1 or y >= h - 1:
        return FILL
    x0 = int(math.floor(x))
    y0 = int(math.floor(y))
    dx = x - x0
    dy = y - y0
    p00 = pixels[y0][x0]
    p10 = pixels[y0][x0 + 1]
    p01 = pixels[y0 + 1][x0]
    p11 = pixels[y0 + 1][x0 + 1]
    return (
        p00 * (1 - dx) * (1 - dy)
        + p10 * dx * (1 - dy)
        + p01 * (1 - dx) * dy
        + p11 * dx * dy
    )


def translate_image(pixels, dx, dy):
    h = len(pixels)
    w = len(pixels[0])
    out = [[FILL] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            out[y][x] = clamp(sample(pixels, x - dx, y - dy))
    return out


def crop_margin_image(pixels, left, top):
    h = len(pixels)
    w = len(pixels[0])
    out = [[FILL] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            sx = x + left
            sy = y + top
            if 0 <= sx < w and 0 <= sy < h:
                out[y][x] = pixels[sy][sx]
    return out


def crop_window_image(pixels, x0, y0, width, height):
    h = len(pixels)
    w = len(pixels[0])
    out = [[FILL] * w for _ in range(h)]
    width = max(8, min(w, width))
    height = max(8, min(h, height))
    ox = (w - width) // 2
    oy = (h - height) // 2
    for y in range(height):
        for x in range(width):
            sx = x0 + x
            sy = y0 + y
            if 0 <= sx < w and 0 <= sy < h:
                out[oy + y][ox + x] = pixels[sy][sx]
    return out


def rotate_image(pixels, degrees):
    h = len(pixels)
    w = len(pixels[0])
    cx = (w - 1) / 2.0
    cy = (h - 1) / 2.0
    rad = math.radians(degrees)
    c = math.cos(rad)
    s = math.sin(rad)
    out = [[FILL] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            xr = x - cx
            yr = y - cy
            src_x = c * xr + s * yr + cx
            src_y = -s * xr + c * yr + cy
            out[y][x] = clamp(sample(pixels, src_x, src_y))
    return out


def visualize_grid(pixels):
    out = [row[:] for row in pixels]
    for y in range(HEIGHT):
        for x in range(WIDTH):
            if x % BLOCK == 0 or y % BLOCK == 0:
                out[y][x] = 255 if (x // BLOCK + y // BLOCK) % 2 == 0 else 0
    return out


def mse(a, b):
    h = len(a)
    w = len(a[0])
    total = 0.0
    for y in range(h):
        for x in range(w):
            d = float(a[y][x]) - float(b[y][x])
            total += d * d
    return total / (h * w)


def psnr(a, b):
    m = mse(a, b)
    if m == 0:
        return 99.0
    return 20.0 * math.log10(255.0 / math.sqrt(m))


def ssim(a, b):
    h = len(a)
    w = len(a[0])
    n = h * w
    ax = sum(sum(row) for row in a) / n
    bx = sum(sum(row) for row in b) / n
    va = 0.0
    vb = 0.0
    cov = 0.0
    for y in range(h):
        for x in range(w):
            da = a[y][x] - ax
            db = b[y][x] - bx
            va += da * da
            vb += db * db
            cov += da * db
    va /= n - 1
    vb /= n - 1
    cov /= n - 1
    c1 = (0.01 * 255) ** 2
    c2 = (0.03 * 255) ** 2
    return ((2 * ax * bx + c1) * (2 * cov + c2)) / ((ax * ax + bx * bx + c1) * (va + vb + c2))


def write_text(path, text):
    Path(path).write_text(text, encoding="utf-8")
    print(text)
