# Lab 02 Report

## Block desynchronization analysis

Write your explanation here.

Required ideas:

- Why 8x8 DCT block offset breaks extraction.
- Why translation, crop, and small rotation desynchronize the block grid.
- What BER, PSNR, and SSIM in metrics.csv show.
