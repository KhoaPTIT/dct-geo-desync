import argparse
import csv
from pathlib import Path

from dct_desync_core import (
    MESSAGE,
    bit_error_rate,
    crop_margin_image,
    crop_window_image,
    extract_message,
    load_pgm,
    psnr,
    rotate_image,
    save_pgm,
    ssim,
    text_to_bits,
    translate_image,
    visualize_grid,
    write_text,
)


TASKS = (
    "grid",
    "baseline",
    "translate_small",
    "translate_large",
    "crop_margin",
    "crop_window",
    "rotate_cw",
    "rotate_ccw",
    "report",
)

REPORTS = {
    "grid": ("grid_report.txt", "GRID_VISUALIZED"),
    "baseline": ("baseline_report.txt", "BASELINE_EXTRACT_OK"),
    "translate_small": ("translate_small_report.txt", "TRANSLATE_SMALL_ATTACK_DONE"),
    "translate_large": ("translate_large_report.txt", "TRANSLATE_LARGE_ATTACK_DONE"),
    "crop_margin": ("crop_margin_report.txt", "CROP_MARGIN_ATTACK_DONE"),
    "crop_window": ("crop_window_report.txt", "CROP_WINDOW_ATTACK_DONE"),
    "rotate_cw": ("rotate_cw_report.txt", "ROTATE_CW_ATTACK_DONE"),
    "rotate_ccw": ("rotate_ccw_report.txt", "ROTATE_CCW_ATTACK_DONE"),
    "report": ("report_check.txt", "REPORT_ANALYSIS_DONE"),
}


def scalar(value):
    value = value.strip()
    if value.lower() in ("true", "false"):
        return value.lower() == "true"
    try:
        if "." in value:
            return float(value)
        return int(value)
    except ValueError:
        return value.strip('"').strip("'")


def load_config(path="lab_config.yaml"):
    cfg = {"global": {}, "attacks": {}}
    section = None
    attack = None
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line:
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        if indent == 0 and line.endswith(":"):
            section = line[:-1].strip()
            attack = None
        elif section == "global" and indent == 2 and ":" in line:
            k, v = line.strip().split(":", 1)
            cfg["global"][k.strip()] = scalar(v)
        elif section == "attacks" and indent == 2 and line.endswith(":"):
            attack = line.strip()[:-1]
            cfg["attacks"][attack] = {}
        elif section == "attacks" and attack and indent == 4 and ":" in line:
            k, v = line.strip().split(":", 1)
            cfg["attacks"][attack][k.strip()] = scalar(v)
    return cfg


def require_files(*names):
    missing = [name for name in names if not Path(name).exists()]
    if missing:
        raise SystemExit(f"Missing files: {', '.join(missing)}. Run python3 setup_lab.py first.")


def global_params(cfg):
    g = cfg["global"]
    return int(g["dct_key"]), float(g["q_delta"]), int(g["repeat_count"])


def clean_decoded(text):
    return text.encode("ascii", errors="replace").decode("ascii")


def append_metrics(task, image, attacked, key, repeat_count):
    stego = load_pgm("stego.pgm")
    expected = text_to_bits(MESSAGE)
    decoded, bits, _ = extract_message(attacked, len(expected), key, repeat_count)
    row = {
        "task": task,
        "image": image,
        "ber": f"{bit_error_rate(expected, bits):.2f}",
        "psnr": f"{psnr(stego, attacked):.2f}",
        "ssim": f"{ssim(stego, attacked):.4f}",
        "decoded_message": clean_decoded(decoded),
    }
    exists = Path("metrics.csv").exists()
    with open("metrics.csv", "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["task", "image", "ber", "psnr", "ssim", "decoded_message"])
        if not exists:
            writer.writeheader()
        writer.writerow(row)
    return row


def attack_config(cfg, task):
    attack = cfg["attacks"].get(task, {})
    if not attack.get("enabled", False):
        raise SystemExit(f"{task} is not enabled in lab_config.yaml")
    return attack


def run_grid():
    require_files("stego.pgm")
    stego = load_pgm("stego.pgm")
    save_pgm("grid_8x8.pgm", visualize_grid(stego))
    write_text("grid_report.txt", "GRID_VISUALIZED\nCreated grid_8x8.pgm\n")


def run_baseline(cfg):
    require_files("stego.pgm")
    key, _, repeat_count = global_params(cfg)
    stego = load_pgm("stego.pgm")
    expected = text_to_bits(MESSAGE)
    decoded, bits, votes = extract_message(stego, len(expected), key, repeat_count)
    ber = bit_error_rate(expected, bits)
    marker = "BASELINE_EXTRACT_OK" if ber == 0.0 and decoded == MESSAGE else "BASELINE_EXTRACT_FAIL"
    write_text(
        "baseline_report.txt",
        f"EXPECTED_MESSAGE = {MESSAGE}\n"
        f"DECODED_MESSAGE = {clean_decoded(decoded)}\n"
        f"BIT_ERROR_RATE = {ber:.2f}\n"
        f"VOTE_MARGIN_PREVIEW = {' '.join(str(v) for v in votes[:24])}\n\n"
        f"{marker}\n",
    )


def nonzero(*values):
    return any(abs(float(v)) > 0 for v in values)


def run_attack(cfg, task):
    require_files("stego.pgm")
    key, _, repeat_count = global_params(cfg)
    a = attack_config(cfg, task)
    stego = load_pgm("stego.pgm")

    if task in ("translate_small", "translate_large"):
        dx = int(a.get("dx", 0))
        dy = int(a.get("dy", 0))
        if not nonzero(dx, dy):
            raise SystemExit(f"{task} requires non-zero dx or dy")
        attacked = translate_image(stego, dx, dy)
        detail = f"dx={dx}, dy={dy}"
    elif task == "crop_margin":
        left = int(a.get("left", 0))
        top = int(a.get("top", 0))
        if not nonzero(left, top):
            raise SystemExit("crop_margin requires non-zero left or top")
        attacked = crop_margin_image(stego, left, top)
        detail = f"left={left}, top={top}"
    elif task == "crop_window":
        x0 = int(a.get("x0", 0))
        y0 = int(a.get("y0", 0))
        width = int(a.get("width", 256))
        height = int(a.get("height", 256))
        if width >= 256 and height >= 256:
            raise SystemExit("crop_window requires width or height below 256")
        attacked = crop_window_image(stego, x0, y0, width, height)
        detail = f"x0={x0}, y0={y0}, width={width}, height={height}"
    elif task in ("rotate_cw", "rotate_ccw"):
        degrees = float(a.get("degrees", 0.0))
        if not nonzero(degrees):
            raise SystemExit(f"{task} requires non-zero degrees")
        if task == "rotate_cw" and degrees <= 0:
            raise SystemExit("rotate_cw requires positive degrees")
        if task == "rotate_ccw" and degrees >= 0:
            raise SystemExit("rotate_ccw requires negative degrees")
        attacked = rotate_image(stego, degrees)
        detail = f"degrees={degrees}"
    else:
        raise SystemExit(f"Unknown attack task {task}")

    image = f"attacked_{task}.pgm"
    save_pgm(image, attacked)
    row = append_metrics(task, image, attacked, key, repeat_count)
    report, marker = REPORTS[task]
    write_text(
        report,
        f"TASK = {task}\n"
        f"IMAGE = {image}\n"
        f"PARAMS = {detail}\n"
        f"BER = {row['ber']}\n"
        f"PSNR = {row['psnr']}\n"
        f"SSIM = {row['ssim']}\n"
        f"DECODED_MESSAGE = {row['decoded_message']}\n\n"
        f"{marker}\n",
    )


def run_report_check():
    require_files("report.md", "metrics.csv")
    text = Path("report.md").read_text(encoding="utf-8", errors="replace").lower()
    required_terms = ["dct", "8x8", "block", "translation", "crop", "rotation", "ber", "psnr", "ssim"]
    missing = [term for term in required_terms if term not in text]
    placeholder_left = "write your explanation here" in text
    too_short = len(text.split()) < 120
    metrics = Path("metrics.csv").read_text(encoding="utf-8", errors="replace")
    metric_rows = [line for line in metrics.splitlines()[1:] if line.strip()]
    attacked = sorted(Path(".").glob("attacked_*.pgm"))
    ok = not missing and not placeholder_left and not too_short and len(metric_rows) >= 6 and len(attacked) >= 6
    marker = "REPORT_ANALYSIS_DONE" if ok else "REPORT_ANALYSIS_INCOMPLETE"
    write_text(
        "report_check.txt",
        f"Missing terms: {', '.join(missing) if missing else 'none'}\n"
        f"Placeholder left: {placeholder_left}\n"
        f"Word count: {len(text.split())}\n"
        f"Metrics rows: {len(metric_rows)}\n"
        f"Attacked images: {len(attacked)}\n\n"
        f"{marker}\n",
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", required=True, choices=TASKS)
    args = parser.parse_args()
    cfg = load_config()
    if args.task == "grid":
        run_grid()
    elif args.task == "baseline":
        run_baseline(cfg)
    elif args.task == "report":
        run_report_check()
    else:
        run_attack(cfg, args.task)


if __name__ == "__main__":
    main()
