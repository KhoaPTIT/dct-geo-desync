from pathlib import Path

from dct_desync_core import MESSAGE, embed_message, make_cover, save_pgm, text_to_bits, write_text


CONFIG = """# Lab 02 DCT desynchronization configuration.
# Edit this file before running each attack task.

global:
  dct_key: 24022026
  q_delta: 32.0
  repeat_count: 5

attacks:
  translate_small:
    enabled: false
    dx: 0
    dy: 0
  translate_large:
    enabled: false
    dx: 0
    dy: 0
  crop_margin:
    enabled: false
    left: 0
    top: 0
  crop_window:
    enabled: false
    x0: 0
    y0: 0
    width: 256
    height: 256
  rotate_cw:
    enabled: false
    degrees: 0.0
  rotate_ccw:
    enabled: false
    degrees: 0.0
"""


REPORT = """# Lab 02 Report

## Block desynchronization analysis

Write your explanation here.

Required ideas:

- Why 8x8 DCT block offset breaks extraction.
- Why translation, crop, and small rotation desynchronize the block grid.
- What BER, PSNR, and SSIM in metrics.csv show.
"""


cover = make_cover()
stego = embed_message(cover, MESSAGE, 24022026, 32.0, 5)
save_pgm("cover.pgm", cover)
save_pgm("stego.pgm", stego)
Path("secret_message.txt").write_text(MESSAGE + "\n", encoding="utf-8")
Path("lab_config.yaml").write_text(CONFIG, encoding="utf-8")
Path("report.md").write_text(REPORT, encoding="utf-8")
Path("metrics.csv").write_text("task,image,ber,psnr,ssim,decoded_message\n", encoding="utf-8")

write_text(
    "setup_report.txt",
    "SETUP_DONE\n"
    f"Message: {MESSAGE}\n"
    f"Payload bits: {len(text_to_bits(MESSAGE))}\n"
    "Created cover.pgm, stego.pgm, lab_config.yaml, metrics.csv, report.md\n",
)
